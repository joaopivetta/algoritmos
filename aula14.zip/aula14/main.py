from exbir_menu import exibir_menu

opcao = exibir_menu()

while True:
    if opcao == 1:
        nome = input("Digite seu nome: ")
        sobrennome = input("Digite seu sobrenome: ")
        validaCPF = valida_CPF()


opcao = exibir_menu()



